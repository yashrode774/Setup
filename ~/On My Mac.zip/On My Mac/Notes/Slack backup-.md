Slack backup:

**How to make the different project root:**

# cd into your current site directory
cd ~/www/MY-SITE-DIR
cd ..
mv MY-SITE-DIR subdir
mkdir MY-SITE-DIR
mv subdir MY-SITE-DIR/

# add /subdir to PHPStorm test configuration (open "run/debug configurations", click "edit configuration templates", change "custom working directory")
# add /subdir to core/phpunit.xml for SIMPLETEST_BASE_URL and BROWSERTEST_OUTPUT_DIRECTORY

**Functional javascript test break point:**

$this->getSession()->executeScript('document.body.style.backgroundColor = "yellow"');
$this->assertSession()->waitForElementVisible('css', '.test-wait', 1000000);

**Browser output:**

<env name="BROWSERTEST_OUTPUT_DIRECTORY" value="/Users/narendra.singh/Sites/field_ui/sites/simpletest/browser_output"/>

**Error logging on Browser:**

$config['system.logging']['error_level'] = 'verbose';
**Using brush: **drush cset system.logging error_level 'verbose' -y

**Get rid of composer changes: **git checkout -- composer.*

**To run tests: **composer require --dev drupal/core-dev --with-all-dependencies : for phpunit
composer require --dev phpspec/prophecy-phpunit:^2

**FPC:**
file_put_contents('/Users/yash.rode/www/sample.html', $this->getSession()->getPage()->getContent());

**host**

<VirtualHost *:80>
    DocumentRoot “/Users/yash.rode/www/drupal11x”
    ServerName drupal11x.test
</VirtualHost> (edited) 

**Drupal site setup:**

vim /usr/local/etc/httpd/extra/httpd-vhosts.conf
# add entry for "/Users/YOURUSER/www/site-building/web" and site-building.test
sudo vim /etc/hosts
# add entry for site-building.test

cd ~/www
# might have to make this directory the first time

composer create-project drupal/recommended-project site-building
cd site-building
composer require drush/drush
cd web
drush site:install --db-url=_sqlite://sites/default/files/.ht.sqlite_

of course you can use something other than vim, I think the guide used code
this should give you a site at _http://site-building.test_

with a username and password of admin

and you can reuse that drush site:install line whenever you want to reinstall drupal

