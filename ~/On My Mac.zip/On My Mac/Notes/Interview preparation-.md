# Interview preparation:
#  **# MYSQL, http, https, ftp, DNS Ports**
**# https://developer.mozilla.org/en-US/docs/Web/HTTP/Status**
**# ajax, js, jquery **
**# Symphony **
**# https://www.geeksforgeeks.org/sql-query-interview-questions/**
**# NF, ACID**
**# SOLID**
**# HTTP, HTTPS difference**
**# Rest API**
**# POST, GET**
**# GET post put patch delete**
**# how to connect MYSQL in Drupal/php**
**https://www.interviewbit.com/web-developer-interview-questions/**
