Int
Hello, my name is Yash Rode. I graduated with a degree in Computer Science Engineering from PICT, Pune. For the past 3.2 years, I've been working at Acquia, where I've sharpened my expertise in PHP, Drupal, MySQL, JavaScript, React, Svelte and object-oriented programming. I've been involved in both the frontend and backend development. I have been working on Drupal core development that goes into making Drupal itself. I have more than 130+ of contributions in Drupal core and I was the top Drupal contributor from India last year!  I'm excited for this PHP developer role. 

* D10:

- I had the privilege of being a part of the Drupal 10 team, where I contributed significantly to enhancing CKEditor5. My focus was on implementing features such as adding images, URL links, and more. This project was a collaborative effort, with a team of five dedicated individuals working together to achieve our goals.

* AMA: 

- we created the migration tool to migrate drupal 7 sites to drupal9 and 10. Which got open sourced recently.

* Automatic Updates:

- I have worked on automatic updates which is a module, which will keep your sites up to date.  This will work for both core as Contrib modules.

* PF:
* We as a community are getting feedback from users and I am trying to implementing them or fix them which Include media revisions UI, Progress bar and some of the major bug fixes. 

* In browser editor:

JSX engine: Replacement for TWIG templating engine.

* Config validation

* Starshot: 

Integrating project browser in to the Drupal. 
